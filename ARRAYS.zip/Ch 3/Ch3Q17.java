import java.util.*;
public class Ch3Q17 
{
 public static void main(String[] args) 
 	{double[][]a = read();
     double[][]b = read();
     double[][]c = read();   
     double[][]e = add(a, b);
     double[][]f = trans(e);
     double[][]d = mult(f, c);
     print(d);
     print(mult(trans(add(a,b)),c));
    }
    static double[][]read()
    {Scanner kbd = new Scanner(System.in);
 	 System.out.print("Enter order of matrix: ");
 	 int m = kbd.nextInt();
 	 int n = kbd.nextInt();
 	 double [][]x = new double[m][n];
 	 System.out.print("Enter elements of matrix rowwise: ");
 	 for(int i = 0; i < m; i++)
 	 	for(int j = 0; j <n; j++)
 	 		x[i][j] = kbd.nextDouble();
 	 return x;
    }
    static double[][]add(double[][]x, double[][]y)
    {double [][]z = new double[x.length][x[0].length];
     for(int i = 0; i < z.length; i++)
     	for(int j = 0; j < z[i].length; j++)
     		z[i][j] = x[i][j]+y[i][j];
     return z;
    }
    static double[][]trans(double[][]x)
    {double [][]y = new double[x[0].length][x.length];
     for(int i = 0; i < y.length; i++)
     	for(int j = 0; j < y[i].length; j++)
     		y[i][j] = x[j][i];
     return y;
    }
    static double[][]mult(double[][]x, double[][]y)
    {double [][]z = new double[x.length][y[0].length];
     for(int i = 0; i < z.length; i++)
     	for(int j = 0; j < z[i].length; j++)
     		for(int k = 0; k < y.length; k++)
     		    z[i][j] += x[i][k]*y[k][j];
     return z;
    }
    static void print(double[][]x)
    {System.out.println("The matrix is: ");
 	 for(int i = 0; i < x.length; i++)
 	     {for(int j = 0; j <x[i].length; j++)
 	 		System.out.print(x[i][j]+"  ");
 	 	  System.out.println();
 	     }
    }
}
