import java.util.*;

public class Ch3Q13 
{
 public static void main(String[] args) 
 	{Scanner kbd = new Scanner(System.in);
 	 System.out.print("Enter no of elements: ");
 	 int n = kbd.nextInt();
 	 int[]x = new int[n+1];
 	 System.out.print("Enter elements in descending order: ");
     for(int i = 0; i < n; i++)
     	x[i] = kbd.nextInt();
     System.out.print("Enter new no to be added: ");
     int i, no = kbd.nextInt();
     System.out.print("The original array is:\n ");
     for(i = 0; i < n; i++)
     	System.out.print(x[i]+"  ");
     for(i = n-1; i >= 0; i--)
     	if(x[i] < no)
     		x[i+1] = x[i];
     	else break;
     x[i+1] = no;
     System.out.print("\nThe new array is:\n ");
     for(i = 0; i <= n; i++)
     	System.out.print(x[i]+"  ");
    }
}
