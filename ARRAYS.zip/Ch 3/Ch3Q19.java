import java.util.*;
public class Ch3Q19 
{
 public static void main(String[] args) 
    {
     for(int i = 3; i <= 15; i+=2)
     	magSquare(i);
    }
    static void magSquare(int n)
    {
     int [][] x = new int[n+1][n+1];
     int no = 1, i = n, j = n/2+1;
     while(no <= n*n)
         {x[i][j] = no;
     	  int newi = i%n + 1;
     	  int newj = j%n + 1;
     	  if(x[newi][newj]==0)
     	    {i = newi; j = newj;}
     	  else i--;
     	  no++;
         } 
     for(i =1; i <= n; i++)
        {for(j = 1; j <= n; j++)
        	System.out.printf("%5d", x[i][j]);
         System.out.println();
        }
     System.out.println();
    }
}
