import java.util.*;
public class Ch3Q11
{public static void main(String[] args) 
 	{Scanner kbd = new Scanner(System.in);
 	 System.out.print("Enter no of elements: ");
 	 int n = kbd.nextInt();
 	 int [] x = new int [n];
 	 System.out.println("Enter elements: ");
 	 for(int i = 0; i < n; i++)
 	 	x[i] = kbd.nextInt();
 	 System.out.print("Enter no to search: ");
 	 int i, no = kbd.nextInt();
 	 for(i = 0; i < n; i++)
 	    if(x[i]==no)break;
 	 if(i<n)
 	 	System.out.println("Found at pos "+ (i+1));
 	 else System.out.println("Not Found");
    }
}
