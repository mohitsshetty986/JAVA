import java.util.*;
class output3
{public static void main(String args[])
      {int x[]={30, 50, 20, 80, 100, 90, 60, 10, 40, 70};
       int y[];
       y = x;
       System.out.println("Array x and y equal is "+Arrays.equals(x, y));
       System.out.println("Array x is:");
       for(int i = 0; i < x.length; i++)
          System.out.print(x[i]+"  ");
       System.out.println();
       Arrays.sort(y, 1, 5);
       System.out.println("Array x and y equal is "+Arrays.equals(x, y));
       System.out.println("Array y is:");
       for(int i = 0; i < y.length; i++)
          System.out.print(y[i]+"  ");
       System.out.println();
       Arrays.sort(x);
       System.out.println("Array x is:");
       for(int i = 0; i < x.length; i++)
          System.out.print(x[i]+"  ");
       System.out.println();
       int z[] = new int[10];
       Arrays.fill(z, 10);
       for(int i = 0; i < z.length; i++)
           {z[i]*= i; z[i]+=10;}
       System.out.println("Array z is:");
       for(int i = 0; i < z.length; i++)
          System.out.print(z[i]+"  ");
       System.out.println();
       System.out.println("Array z and y equal is "+Arrays.equals(z, y));
       int z1[] = new int[5];
       System.arraycopy(z, 3, z1, 0, 5);    	 
       System.out.println("Array z1 is:");
       for(int i = 0; i < z1.length; i++)
          System.out.print(z1[i]+"  ");
       System.out.println();
       for(int no = 7; no <= 700; no*=10)
          {int pos = Arrays.binarySearch(x, no);
           System.out.println("position of "+ no + " in x array is = " + pos);
          }
      }
}
