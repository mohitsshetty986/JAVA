import java.util.*;
public class Ch3Q10
{public static void main(String[] args) 
 	{Scanner kbd = new Scanner(System.in);
 	 int n = 5;
 	 int [] a = new int [n];
 	 System.out.println("Enter "+n+" integers: ");
 	 for(int i = 0; i < n; i++)
 	 	a[i] = kbd.nextInt();
 	 for(int i = 1; i < n; i++)
 	 	for(int j = 0; j < n-i; j++)
 	 		if(a[j] > a[j+1])
 	 		  {int temp = a[j];
 	 		   a[j] = a[j+1];
 	 		   a[j+1] = temp;
 	 		  }
 	 System.out.println("The sorted nos are:");
 	 for(int i = 0; i < n; i++)
 	 	System.out.print(a[i]+" ");
 	 System.out.println();
    }
}
