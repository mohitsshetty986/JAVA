import java.util.*;
public class Ch3Q9 
{
 public static void main(String[] args) 
    {
     Scanner kbd = new Scanner(System.in);
     System.out.print("How many elements: ");
     int n = kbd.nextInt();
     int x[] = new int[n];
     System.out.print("Enter the elements: ");
     for(int i = 0; i < n; i++)
     	x[i] = kbd.nextInt();
     System.out.println("The original array is:");
     for(int i = 0; i < n; i++)
     	System.out.print(x[i]+"  ");
     System.out.println();
     for(int i = 0; i < n/2; i++)
        {int temp = x[i];
         x[i] = x[n-1-i];
         x[n-1-i] = temp;
        }
     System.out.println("The reversed array is:");
     for(int i = 0; i < n; i++)
     	System.out.print(x[i]+"  ");
     System.out.println();
    }
}
