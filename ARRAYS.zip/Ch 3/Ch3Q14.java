import java.util.*;
public class Ch3Q14 
{public static void main(String[] args) 
    {Scanner kbd = new Scanner(System.in);
     System.out.print("Enter no of points: ");
     int n = kbd.nextInt();
     double sxy = 0, sx = 0, sy = 0, sxsq = 0;
     System.out.println("Enter the x and y co-ordinates: ");
     for(int i = 0; i < n ; i++)
     	{double x = kbd.nextDouble();
     	 double y = kbd.nextDouble();
     	 sxy += x*y; sx += x; sy += y; sxsq += x*x;
        }
     double m = (n*sxy-sx*sy)/(n*sxsq -sy*sy);
     double c = (sy-m*sx)/n;
     System.out.println("The equation of line is y = "+m+"x + "+c);
    }
}
