import java.util.*;
public class Ch3Q15 
{public static void main(String[] args) 
 	{Scanner kbd = new Scanner(System.in);
     System.out.print("Enter no of elements: ");
     int n = kbd.nextInt();
     double[]a = new double[n];
     System.out.print("Enter elements: ");
     for(int i = 0; i < n; i++)
     	a[i] = kbd.nextDouble();
     double max1 = a[0] > a[1] ? a[0] : a[1];
     double max2 = a[0] < a[1] ? a[0] : a[1];
     for(int i = 2; i < n; i++)
     	if(a[i] > max1)
     	   {max2 = max1;
     	    max1 = a[i];
     	   }
     	else if(a[i] > max2)
     		    max2 = a[i];
     System.out.println("Maximum = "+max1);
     System.out.println("Second Maximum = "+max2);
    }
}

