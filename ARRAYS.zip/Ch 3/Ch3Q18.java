import java.util.*;
public class Ch3Q18 
{
 public static void main(String[] args) 
    {Scanner kbd = new Scanner(System.in);
     System.out.print("How many lines: ");
     int n = kbd.nextInt();
     int [][]x = new int[n][];
     for(int i = 0; i < n; i++)
     	x[i] = new int[i+1];
     for(int i =0; i < n; i++)
        {for(int j = 1; j <= n+1-i;j++)
        	System.out.print(" ");
         for(int j = 0; j <= i; j++)
     	   {if(i==j || j == 0)
     		   x[i][j] = 1;
     		else x[i][j] = x[i-1][j-1] + x[i-1][j];
     		System.out.print(x[i][j] + " ");
     	   }
     	System.out.println();
        }
    }
}
