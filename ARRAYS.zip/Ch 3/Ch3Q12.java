import java.util.*;
public class Ch3Q12
{public static void main(String[] args) 
 	{Scanner kbd = new Scanner(System.in);
 	 System.out.print("Enter no of elements: ");
 	 int n = kbd.nextInt();
 	 int  x []= new int [n];
 	 System.out.println("Enter elements: ");
 	 for(int i = 0; i < n; i++)
 	 	x[i] = kbd.nextInt();
 	 System.out.print("Enter no to search: ");
 	 int i, no = kbd.nextInt();
 	 boolean found = false;
 	 for(i = 0; i < n; i++)
 	    if(x[i]==no)
 	      {System.out.println("Found at pos "+ (i+1));
 	       found = true;
 	      }
 	 if(!found)
 	 	System.out.println("Not Found");
    }
}
