import java.util.*;
public class Ch1Q33
{
    public static void main(String[] args) 
    {int i = 2;
     int j = (i=3) * i;
     System.out.println("i = " + i + "\tj = " + j);
     int b = 9;
     b = b + (b = 3); 
     System.out.println("b = " + b);
     int a = 9;
     a += (a = 3); 
     System.out.println("a = " + a);
     double d = 8e+307;
     System.out.println("Answer 1 = " + 4.0 * d * 0.5);
     System.out.println("Answer 2 = " + 2.0 * d);
    }
}
