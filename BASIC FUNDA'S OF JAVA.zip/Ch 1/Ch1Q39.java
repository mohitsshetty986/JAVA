import java.util.*;
public class Ch1Q39 
{
 public static void main(String[] args) 
 	{Scanner kbd = new Scanner(System.in);
 	 System.out.print("Enter Co-ordinates of first vertex: ");
 	 double x1 = kbd.nextDouble();
 	 double y1 = kbd.nextDouble();
 	 System.out.print("Enter Co-ordinates of second vertex: ");
 	 double x2 = kbd.nextDouble();
 	 double y2 = kbd.nextDouble();
 	 System.out.print("Enter Co-ordinates of third vertex: ");
 	 double x3 = kbd.nextDouble();
 	 double y3 = kbd.nextDouble();
 	 double a = Math.sqrt((x1-x2)*(x1-x2)+(y1-y2)*(y1-y2));
 	 double b = Math.sqrt((x1-x3)*(x1-x3)+(y1-y3)*(y1-y3));
 	 double c = Math.sqrt((x3-x2)*(x3-x2)+(y3-y2)*(y3-y2));
 	 double s = (a+b+c)/2;
 	 double area = Math.sqrt(s*(s-a)*(s-b)*(s-c));
 	 System.out.println("Side of square = " + Math.sqrt(area));
 	}
}
