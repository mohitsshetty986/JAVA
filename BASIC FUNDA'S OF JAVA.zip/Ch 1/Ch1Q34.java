import java.util.*;
public class Ch1Q34
{
 public static void main(String[] args) 
 	{int a =5, b;
 	 b = ++a + a++; System.out.println("a = " + a + "\tb = "+ b);
     b = ++a + ++a; System.out.println("a = " + a + "\tb = "+ b);
     b = a++ + a++; System.out.println("a = " + a + "\tb = "+ b);
     b = ++a + a++ * ++a; System.out.println("a = " + a + "\tb = "+ b);
     b = ++a * a++ + ++a; System.out.println("a = " + a + "\tb = "+ b);
     b = (++a + a++) * ++a; System.out.println("a = " + a + "\tb = "+ b);   
    }
}
