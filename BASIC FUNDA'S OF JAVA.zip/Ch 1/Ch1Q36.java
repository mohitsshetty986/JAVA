import java.util.*;
public class Ch1Q36
{
 public static void main(String[] args) 
 	{Scanner kbd = new Scanner(System.in);
 	 System.out.print("Enter wt in Kg: ");
 	 double kg = kbd.nextDouble();
 	 int lb = (int)(kg*2.20462);
 	 int oz = (int) ((kg*2.20462-lb)*16);
 	 double dr = (((kg*2.20462-lb)*16)-oz)*16;
 	 System.out.printf("%d lb, %d oz and %.2f drams", lb, oz, dr);
    }
}
