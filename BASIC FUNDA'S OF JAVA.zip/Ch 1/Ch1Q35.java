import java.util.*;
public class Ch1Q35
{
 public static void main(String[] args) 
 	{
 	 System.out.print("Enter temp in Farenheit: ");
 	 Scanner kbd = new Scanner(System.in);
 	 double faren = kbd.nextDouble();
 	 double cel = (faren-32)/1.8;
 	 System.out.println("Equivalent Temp = " + cel);
        
    }
}
