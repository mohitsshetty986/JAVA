import java.util.*;
public class Ch1Q38
{
 public static void main(String[] args) 
 	{Scanner kbd = new Scanner(System.in);
 	 System.out.print("Enter inductance, capacitance and resistance: ");
 	 double l = kbd.nextDouble();
 	 double c = kbd.nextDouble();
 	 double r = kbd.nextDouble();
 	 double f = Math.sqrt(1/(l*c)-r*r/(4*c*c));
 	 System.out.println("Freq = " + f);
    }
}
