import java.util.*;
public class Ch1Q37 
{
 public static void main(String[] args) 
 	{
 	 System.out.print("Enter radius of a sphere: ");
 	 Scanner kbd = new Scanner(System.in);
 	 double rad = kbd.nextDouble();
 	 double sarea = 4*Math.PI*rad*rad;
 	 double vol = 4*Math.PI*rad*rad*rad/3;
 	 System.out.println("Surface area = " + sarea);
     System.out.println("Volume = " + vol);   
    }
}
