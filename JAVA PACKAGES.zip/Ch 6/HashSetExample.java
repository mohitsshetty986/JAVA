import java.io.*;
import java.util.*;

public class HashSetExample 
{public static void main(String[] args) throws IOException
 	{InputStreamReader isr = new InputStreamReader(System.in);
 	 BufferedReader kbd = new BufferedReader(isr);
 	 HashSet<Object> v = new HashSet<Object>();
 	 int choice;
 	do
 	{System.out.println("Enter 1 to add");
     	System.out.println("Enter 2 to delete");
     	System.out.println("Enter 3 to print");
     	System.out.println("Enter 4 to quit");
     	System.out.print("Enter your choice: ");
     	choice = Integer.parseInt(kbd.readLine());
     	switch(choice)
     		{case 1:System.out.print("Enter the no to be added: ");
     		        int no = Integer.parseInt(kbd.readLine());
              		v.add(no); break;
      		 case 2:System.out.print("Enter the no to be deleted: ");
      		        int no1 = Integer.parseInt(kbd.readLine());
              		v.remove(no1); break;
      		 case 3:System.out.println(v);
     		}
 	 	}
     while(choice != 4);
    }
}
