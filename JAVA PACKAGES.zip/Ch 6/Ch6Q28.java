import java.io.*;
import java.util.*;
class item
{private String name;
 private double price;
	public void read()throws IOException
	{InputStreamReader isr = new InputStreamReader(System.in);
 	 BufferedReader kbd = new BufferedReader(isr);
	 System.out.print("Enter name: ");
	 name = kbd.readLine();
	 System.out.print("Enter price: ");
	 price = Double.parseDouble(kbd.readLine());
	}
	public String toString()
	{return name+"\t"+Double.toString(price);
	}
}

public class Ch6Q28
{public static void main(String[] args) throws IOException
 	{InputStreamReader isr = new InputStreamReader(System.in);
 	 BufferedReader kbd = new BufferedReader(isr);
 	 Vector <item> v = new Vector<item>();
 	 int choice;
 	 do{
 	 	System.out.println("Enter 1 to add");
     	System.out.println("Enter 2 to delete");
     	System.out.println("Enter 3 to print");
     	System.out.println("Enter 4 to quit");
     	System.out.print("Enter your choice: ");
     	choice = Integer.parseInt(kbd.readLine());
     	switch(choice)
     		{case 1:item a = new item();
              		a.read();
              		System.out.print("Enter position <="+v.size()+": ");
     		  		int pos = Integer.parseInt(kbd.readLine());
              		v.add(pos, a); 
              		break;
      		 case 2:System.out.print("Enter position <"+v.size()+": ");
      	      		pos = Integer.parseInt(kbd.readLine());
              		v.removeElementAt(pos); 
              		break;
      		 case 3:System.out.println(v);
     		}
 	 	}
     while(choice != 4);
    }
}
