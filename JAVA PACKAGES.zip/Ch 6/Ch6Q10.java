import java.io.*;
class Ch6Q10
{public static void main(String[] args) throws IOException 
    {BufferedReader kbd = new BufferedReader (new InputStreamReader(System.in));
     System.out.print("Enter a string: ");
     String str = kbd.readLine();
     char [] s = str.toCharArray();
     for(int i = 0; i <str.length(); i++)
     	System.out.println(i+"\t"+s[i]);
    }
}
