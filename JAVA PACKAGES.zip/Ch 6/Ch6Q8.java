import java.io.*;
class Ch6Q8
{public static void main(String args[ ])throws IOException
 {InputStreamReader isr = new InputStreamReader(System.in);
  BufferedReader kbd = new BufferedReader (isr);
  System.out.print("Enter the string: ");
  String str = kbd.readLine().trim();
  int i = 0, j = str.length()-1;
  while(i < j)
   	if(str.charAt(i) != str.charAt(j))
   	  break;
   	else {i++; j--;}
  if(i>=j)
    System.out.println("Palindrome");
  else System.out.println("Not a Palindrome");
 }
}
