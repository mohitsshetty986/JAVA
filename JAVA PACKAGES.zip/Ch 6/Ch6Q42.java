import distance.*;
class MetBrit 
{
 public static void main(String[] args) 
    {
     Metric m = new Metric(5, 10);
     British b = new British(5, 10);
     m.display(); b.display();
     Metric m1 = m.add(b);
     m1.display();
    }
}
