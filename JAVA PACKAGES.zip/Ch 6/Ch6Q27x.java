import java.io.*;
import java.util.*;
public class Ch6Q27x 
{public static void main(String[] args) throws IOException
 	{InputStreamReader isr = new InputStreamReader(System.in);
 	 BufferedReader br = new BufferedReader(isr);
 	 Vector <String> v = new Vector<String>(5);
 	 int choice;
 	 do{
 	 	System.out.println("Enter 1 to add name");
     	System.out.println("Enter 2 to delete name by name");
     	System.out.println("Enter 3 to print names");
     	System.out.println("Enter 4 to quit");
     	System.out.print("Enter your choice: ");
     	choice = Integer.parseInt(br.readLine());
     	switch(choice)
     		{case 1:System.out.print("Enter name: ");
     			    String s = br.readLine();
              		int pos = v.indexOf(s);
              		if(pos==-1)
              		   {v.add(s);
              		    System.out.println("Name added");
              		   }
              		else System.out.println("Name already exists");
              		break;
      		 case 2: System.out.print("Enter name: ");
                     s = br.readLine();
                     pos = v.indexOf(s);
              		 if(pos==-1)
              		    System.out.println("Name does not exist");
              		else {v.removeElementAt(pos); 
              			  System.out.println("Name deleted");
              		     }
      	      		break;
      		 case 3:System.out.println(v);
     		}
 	 	}
     while(choice != 4);
    }
}
