import java.util.*;
class vectorDemo
{
 public static void main(String args[])
 {
  Vector v = new Vector();
  System.out.println("At the beginning");
  System.out.println("Capacity = " + v.capacity());
  System.out.println("Size = " + v.size());
  Byte a= new Byte("5");
  Integer b=new Integer(500);
  Float c=new Float(123.45);
  Character d = new Character ('A');
  String e = "Sample Vector";
  v.addElement(a);
  v.addElement(b);
  v.addElement(c);
  v.addElement(d);
  v.addElement(e);
  System.out.println("After adding elements");
  System.out.println("Capacity = " + v.capacity());
  System.out.println("Size = " + v.size());
  for (int i=0; i<v.size(); i++)
  System.out.println(v.elementAt(i));
 }
}
