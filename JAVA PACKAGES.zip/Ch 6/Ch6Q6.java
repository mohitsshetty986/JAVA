import java.io.*;
class Ch6Q6
{public static void main(String args[])throws IOException
 {InputStreamReader isr = new InputStreamReader(System.in);
  BufferedReader kbd = new BufferedReader (isr);
  int n;
  System.out.print("Enter no of strings: ");
  n = Integer.parseInt(kbd.readLine());
  String str[]=new String[n];
  for (int i=0; i<n; i++)
       {System.out.print("Enter string no "+(i+1)+": ");
       	str[i]=kbd.readLine();
       }
  System.out.println("Required Strings are");
  for (int i=0; i<n; i++)
       if(str[i].charAt(0)==str[i].charAt(str[i].length()-1))
          System.out.println(str[i]);
  }
}
