import java.io.*;
class Ch6Q3
{public static void main(String args[])throws IOException
 {InputStreamReader isr = new InputStreamReader(System.in);
  BufferedReader kbd = new BufferedReader (isr);
  System.out.print("Enter a string: ");
  String str = kbd.readLine();
  int count = 0;
  for(int i = 0; i < str.length()-1;i++)
  	  if(Character.isWhitespace(str.charAt(i)))
  	  	 if(Character.isLetter(str.charAt(i+1)))
    /* if(str.charAt(i) == ' ' 
     	&& str.charAt(i+1) >= 'a' && str.charAt(i+1)<='z'
     	|| str.charAt(i+1) >= 'A' && str.charAt(i+1)<='Z'
       )*/
     	count++;
  if(str.charAt(0) == ' ') 
  	 System.out.println("No of words are " + count);
  else System.out.println("No of words are " + (count+1));
 }
} 

  
  
  