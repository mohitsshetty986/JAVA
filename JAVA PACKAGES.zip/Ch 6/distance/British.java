package distance;
import java.util.*;

public class British
{int ft;
 double inch;
 public void read()
 {Scanner kbd = new Scanner(System.in);
  System.out.print("Enter distance in fts and inches: ");
  ft = kbd.nextInt();
  inch = kbd.nextDouble();
 }
 public void display()
 {System.out.println(ft+" fts and "+inch+" inches");
 }
 public British(int ft, double inch)
 {this.ft = ft; this.inch = inch;
 }
 public British(){}
 public int getft()
 {return ft;}
 public double getinch()
 {return inch; }
 static public Metric add (Metric m, British b)
 {double totcm = m.mt*100 + m.cm + (b.ft*12+b.inch)*2.54;
  return new Metric((int) (totcm / 100), totcm % 100);
 }
}
