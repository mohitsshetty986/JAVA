package distance;
import java.util.*;

public class Metric
{int mt;
 double cm;
 static int count;
 public static int getcount()
 {return count;
 }
 public void read()
 {Scanner kbd = new Scanner(System.in);
  System.out.print("Enter distance in mts and cms: ");
  mt = kbd.nextInt();
  cm = kbd.nextDouble();
 }
 public void display()
 {System.out.println(mt+" mts and "+cm+" cms");
 }
 public Metric(int mt, double cm)
 {this.mt = mt; this.cm = cm; count++;
 }
 public Metric(){count++;}
 public int getmt()
 {return mt;
 }
 public double getcm()
 {return cm;
 }
 public Metric add(British b)
 {double totcm = mt*100 + cm + (b.ft*12+b.inch)*2.54;
  int mts = (int) (totcm / 100);
  double cms = totcm % 100;
  return new Metric(mts, cms);
 }
 public void add(Metric m, British b)
 {double totcm = m.mt*100 + m.cm + (b.ft*12+b.inch)*2.54;
  mt = (int) (totcm / 100);
  cm = totcm % 100;
 }
 public void add(British b, Metric m3)
 {double totcm = mt*100 + cm + (b.ft*12+b.inch)*2.54;
  m3.mt = (int) (totcm / 100);
  m3.cm = totcm % 100;
 }
}
 