import java.io.*;
import java.util.*;
public class Ch6Q27b 
{public static void main(String[] args) throws IOException
 	{InputStreamReader isr = new InputStreamReader(System.in);
 	 BufferedReader br = new BufferedReader(isr);
 	 LinkedList <String> v = new LinkedList<String>();
 	 int choice;
 	 for(int i = 0; i < 5; i++)
 	    {System.out.print("Enter name: ");
     	 String s = br.readLine();
         v.add(s);
 	    }
 	 do{
 	 	System.out.println("Enter 1 to add name");
     	System.out.println("Enter 2 to delete name by position");
     	System.out.println("Enter 3 to delete name by name");
     	System.out.println("Enter 4 to print names");
     	System.out.println("Enter 5 to quit");
     	System.out.print("Enter your choice: ");
     	choice = Integer.parseInt(br.readLine());
     	switch(choice)
     		{case 1:System.out.print("Enter name: ");
     			    String s = br.readLine();
              		System.out.print("Enter position <="+v.size()+": ");
     		  		int pos = Integer.parseInt(br.readLine());
              		v.add(pos, s); break;
      		 case 2:System.out.print("Enter position <"+v.size()+": ");
      	      		pos = Integer.parseInt(br.readLine());
              		v.remove(pos); break;
             case 3: System.out.print("Enter name: ");
                     s = br.readLine();
                     for(int i = 0; i < v.size(); i++)
                    	if(v.get(i).compareToIgnoreCase(s)==0)
      	      		       v.remove(i); 
      	      		break;
      		 case 4:System.out.println(v);
     		}
 	 	}
     while(choice != 5);
    }
}
