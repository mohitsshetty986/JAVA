import java.io.*;
class Ch6Q4
{public static void main(String args[ ])throws IOException
 {InputStreamReader isr = new InputStreamReader(System.in);
  BufferedReader kbd = new BufferedReader (isr);
  String vowels = "AEIOUaeiou";
  String str;
  System.out.println("Enter a string");
  str = kbd.readLine();
  int len = str.length(), vow = 0, totchar = 0;
  for (int i=0; i<len; i++)
  {char ch = str.charAt(i);
   if(ch >='a'&&ch<='z'||ch >= 'A'&& ch <='Z')
     {totchar++;
   	  for(int j = 0; j < vowels.length(); j++)
    	  if(ch == vowels.charAt(j))
    	  	 {vow++; break;}
     }
  }
  System.out.println("No. of vowels = "+vow);
  System.out.println("No. of consonants = "+(totchar -vow));
}
}