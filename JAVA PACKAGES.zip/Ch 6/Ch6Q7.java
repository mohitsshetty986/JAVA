import java.io.*;
class Ch6Q7
{public static void main(String args[ ])throws IOException
 {InputStreamReader isr = new InputStreamReader(System.in);
  BufferedReader kbd = new BufferedReader (isr);
  System.out.print("Enter no of strings: ");
  int n = Integer.parseInt(kbd.readLine());
  String str[]=new String[n];
  for (int i = 0; i < n; i++)
      {System.out.print("Enter string no "+(i+1)+": ");
       str[i] = kbd.readLine();
      }
  for (int i=0; i<n-1; i++)
     for (int j=i+1; j<n; j++)
      if (str[i].compareTo(str[j])>0)
	      {String t=str[j];
	       str[j]=str[i];
	       str[i]=t;
	      }
  System.out.println("Strings in alphabetical order");
  for (int i=0; i<n; i++)
    System.out.println(str[i]);
 }
}
