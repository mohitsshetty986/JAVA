//import java.io.*;
class Ch6Q11
{public static void main(String[] args) throws java.io.IOException 
    {java.io.BufferedReader kbd = new java.io.BufferedReader (new java.io.InputStreamReader(System.in));
     System.out.print("Enter a string: ");
     String str = kbd.readLine();
     char [] strarray = str.toCharArray();
     strarray[0]=Character.toUpperCase(strarray[0]);
     //if(strarray[0]>='a'&&strarray[0]<='z')
     	//strarray[0]-='a'-'A';
     for(int i = 0; i <str.length(); i++)
     	if(strarray[i] == ' ')
     	   strarray[i+1]=Character.toUpperCase(strarray[i+1]);
     	   //if(strarray[i+1]>='a'&&strarray[i+1]<='z')
     	//strarray[i+1]-='a'-'A';
     str = new String(strarray);
     System.out.println(str);
     }
}
