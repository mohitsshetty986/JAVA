import java.util.*;
class vectorDemo1
{
 public static void main(String args[])
 {
  Vector<Object> v= new Vector<Object>();
  System.out.println("At the beginning");
  System.out.println("Capacity = " + v.capacity());
  System.out.println("Size = " + v.size());
  Byte a = 5;
  Integer b = 500;
  Float c = 123.45f;
  Character d = 'A';
  String e = "Sample Vector";
  v.addElement(a);
  v.addElement(b);
  v.addElement(c);
  v.addElement(d);
  v.addElement(e);
  v.insertElementAt("I Love U", 3);
  System.out.println("After adding elements");
  System.out.println("Capacity = " + v.capacity());
  System.out.println("Fount at 4 = "+v.elementAt(4));
  Object o1 = v.elementAt(3);
  System.out.println("Type at 3 = "+ o1.getClass().getName());
  System.out.println("Size = " + v.size());
  //complex1 com = new complex1(2, 3);
//  v.addElement(com);
  for (int i=0; i<v.size(); i++)
  System.out.println(v.elementAt(i));
  
 }
}
