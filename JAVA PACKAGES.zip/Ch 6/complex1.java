import java.util.*;
public class complex1 
{private double real, imag;
 public complex1(double real, double imag)
 {this.real = real; this.imag = imag;
 }
 public void display()
 {
 	System.out.println(real + "+"+imag+"i");
  
 }
 public String toString()
 {return real + "+"+imag+"i";
 }
 
}
class trial
{ public static void main(String[] args) 
    {complex1 x = new complex1(4,3);
     x.display();
     System.out.println(x);
    }
}
