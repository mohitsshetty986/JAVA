import java.io.*;

public class Ch6Q5x 
{
    public static void main(String[] args) throws IOException
    {InputStreamReader isr = new InputStreamReader(System.in);
     BufferedReader br = new BufferedReader(isr);
     System.out.print("Enter a string: ");
     String str = br.readLine();
     int count1 = 0, count2 = 0, count3 = 0, count4 = 0, count5 = 0;
     for(int i = 0; i < str.length(); i++)
        {char ch = str.charAt(i);
         if(ch >='A' && ch <='Z')
         	count1++;
         else if(ch >='a' && ch <='z')
         	     count2++;
         	  else if(ch == ' ')
         	  	      count3++;
         	  	   else if(ch >='0' && ch <='9')
         	  	   	       count4++;
         	  	   	    else count5++;
         }
     System.out.println("No of uppercase characters = "+count1);
     System.out.println("No of uppercase characters = "+count2);
     System.out.println("No of blank spaces = "+count3);
     System.out.println("No of digits = "+count4);
     System.out.println("No of special characters = "+count5);
    }
}
