import java.io.*;
public class Ch6Q9 
{
 public static void main(String[] args)throws IOException
    {InputStreamReader isr = new InputStreamReader(System.in);
     BufferedReader br = new BufferedReader(isr);
     System.out.println("Enter a string: ");
     String str = br.readLine();
     System.out.println("Enter the character: ");
     char ch = br.readLine().trim().charAt(0);
     System.out.println("The character = "+ch);
     int freq = 0;
     for(int j = 0; j < str.length(); j++)
        {if(ch == str.charAt(j))
            freq++;
        }
     System.out.println("The frequency = "+freq);
    }
}
