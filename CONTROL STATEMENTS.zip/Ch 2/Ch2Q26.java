import java.util.*;
public class Ch2Q26 
{
 public static void main(String[] args) 
    {Scanner kbd = new Scanner(System.in);
     System.out.print("Enter an integer: ");
     int no = kbd.nextInt();
     int sum = 0, no1 = no;
     while(no!=0)
          {int dig = no%10;
           sum += dig*dig*dig;
           no /= 10;
          }
     if(sum == no1)
     	System.out.println("Armstrong No");
     else System.out.println("Not an Armstrong No");
    }
}
