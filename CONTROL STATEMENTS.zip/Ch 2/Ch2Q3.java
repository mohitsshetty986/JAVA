import java.util.*;
public class Ch2Q3 
{
 public static void main(String[] args) 
    {Scanner kbd = new Scanner(System.in);
     System.out.print("Enter co-ordinates of the center: ");
     double x = kbd.nextDouble();
     double y = kbd.nextDouble();
     System.out.print("Enter radius of the center: ");
     double rad = kbd.nextDouble();
     System.out.print("Enter co-ordinates of the point: ");
     double x1 = kbd.nextDouble();
     double y1 = kbd.nextDouble();
     double dist = Math.sqrt(Math.pow(x1-x,2)+Math.pow(y1-y, 2));
     if(dist==rad)
     	System.out.println("On the circle");
     else if(dist < rad)
     		 System.out.println("In the circle");
     	  else System.out.println("Outside the circle");
    }
}
