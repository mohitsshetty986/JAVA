import java.util.*;
public class Ch2Q20 
{
 public static void main(String[] args) 
    {Scanner kbd = new Scanner(System.in);
     System.out.print("Enter an integer: ");
     int no = kbd.nextInt();
     int i = 2;
     while(no != 1)
     	   if(no%i==0)
     	      {System.out.print(i+" ");
     	       no = no/i;
     	      }
     	   else i++;
    }
}
