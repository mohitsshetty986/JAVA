import java.util.*;
public class Ch2Q22 
{
 public static void main(String[] args) 
    {Scanner kbd = new Scanner(System.in);
     System.out.print("Enter an integer: ");
     int no = kbd.nextInt();
     int count = 0;
     while(no != 1)
     {if(no%2==0)
        no = no /2;
      else no = no*3 + 1;
      System.out.print(no+" ");
      count++;
     }
     System.out.println("\nCount = "+count);
    }
}
