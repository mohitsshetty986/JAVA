import java.util.*;
public class Ch2Q25 
{
 public static void main(String[] args) 
    {Scanner kbd = new Scanner(System.in);
     System.out.print("Enter the integer: ");
     int n = kbd.nextInt();
     if(n==1)
     	System.out.println(0);
     else System.out.print(0+"  "+1+"  ");
     int first = 0, second = 1, third = 1, count = 2;
     while(count < n)
          {third = first + second;
           System.out.print(third+"  ");
           first = second;
           second = third;
           count++;
          }
    }
}
