import java.util.*;
public class Ch2Q41 
{
 public static void main(String[] args) 
    {Scanner kbd = new Scanner(System.in);
     System.out.print("Enter an integer: ");
     int no = kbd.nextInt();
     System.out.println("Sum = "+sum(no));
    }
 static int sum(int no)
    {if(no == 0)return 0;
     return sum(no/10) + no%10;
    }
}
