import java.util.*;
public class Ch2Q44 
{static double area(double rad)
    { return Math.PI * rad *rad;
    }
 static double area(double length, double breadth)
    { return length * breadth;
    }
 static double area(double a, double b, double c)
    { double s = (a+b+c)/2;
      return Math.sqrt(s*(s-a)*(s-b)*(s-c));
    }
 public static void main(String[] args) 
    {
     System.out.println("Area = "+area(4));
     System.out.println("Area = "+area(4, 5));
     System.out.println("Area = "+area(3, 4, 5));
    }
}
