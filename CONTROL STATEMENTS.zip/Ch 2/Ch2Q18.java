public class Ch2Q18 
{
 public static void main(String[] args) 
 	{int sum = 0, i = 2, j = 0, k = 0;
 	 for(sum=0, i=2; i<=8; i+=2)
 	    {j=1;
 	     while(j<4)
 	     {k=j;
 	      do{sum++;
 	         k+=2;
 	        }
 	      while(k<=3);
 	      j++;  
 	     }
 	    }
 	 System.out.printf("%d %d %d %d\n", sum, i, j, k);
    }
}
