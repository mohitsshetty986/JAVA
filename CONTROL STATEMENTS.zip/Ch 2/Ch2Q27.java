import java.util.*;
public class Ch2Q27 
{
 public static void main(String[] args) 
    {Scanner kbd = new Scanner(System.in);
     System.out.print("Enter an integer: ");
     int n = kbd.nextInt();
     for(int no = 1; no < n; no++)
	     {int sum = 0, no1 = no;
	      while(no1!=0)
	          {int dig = no1%10;
	           sum += dig*dig*dig;
	           no1 /= 10;
	          }
	       if(sum == no)
	     	  System.out.println(no+"  ");
	     }
     }
}