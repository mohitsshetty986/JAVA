import java.util.*;

public class Ch2Q10c 
{
    public static void main(String[] args) 
    {Scanner kbd = new Scanner(System.in);
     System.out.print("Enter x: ");
     double x = kbd.nextDouble();
     double y; 
     y = x>0?1:(x<0?-1:0);
     System.out.println("x = "+x+"\ny= "+y);
    }
}
