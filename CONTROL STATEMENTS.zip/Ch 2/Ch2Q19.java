import java.util.*;
public class Ch2Q19 
{
 public static void main(String[] args) 
    {Scanner kbd = new Scanner(System.in);
     System.out.print("Enter two integers: ");
     int n1 = kbd.nextInt();
     int n2 = kbd.nextInt();
     if(n2 < n1)
       {int temp = n1;
        n1 = n2;
        n2 = temp;
       }
     int sum = 0, count = 0;
     for(int no = n1+1; no < n2; no++)
     	 if(no%7==0)
     	   {sum += no;
     	    count++;
     	   }
     System.out.println("Sum = "+sum);
     System.out.println("Count = "+count);
    }
}
