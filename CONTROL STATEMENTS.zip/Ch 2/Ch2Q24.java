import java.util.*;
public class Ch2Q24 
{
 public static void main(String[] args) 
    {Scanner kbd = new Scanner(System.in);
     System.out.print("Enter the integer: ");
     int no = kbd.nextInt();
     if(no==1)
     	System.out.println(0);
     else System.out.print(0+"  "+1+"  ");
     int first = 0, second = 1, third = 1;
     while(third <= no)
          {
           System.out.print(third+"  ");
           first = second;
           second = third;
           third = first + second;
          }
    }
}
