import java.util.*;

public class Ch2Q10a 
{
    public static void main(String[] args) 
    {Scanner kbd = new Scanner(System.in);
     System.out.print("Enter x: ");
     double x = kbd.nextDouble();
     double y = 0;
     if(x>0)y = 1;
     if(x<0)y = -1;
     System.out.println("x = "+x+"\ny= "+y);
    }
}
