import java.util.*;
public class Ch2Q29 
{public static void main(String[] args) 
    {Scanner kbd = new Scanner(System.in);
     System.out.print("How many students: ");
     int n = kbd.nextInt();
     int count1 = 0, count2 = 0, count3 = 0, count4 = 0;
     for(int i = 1; i <= n; i++)
        {System.out.print("Enter marks: ");
         byte marks = kbd.nextByte();
         switch((marks-1)/20)
         {case 4: count1++; break;
          case 3: count2++; break;
          case 2: count3++; break;
          case 1: 
          case 0: count4++; break;
         }
        }
      System.out.println("No of students in 81-100 range: "+count1);
      System.out.println("No of students in 61-80 range: "+count2);
      System.out.println("No of students in 41-60 range: "+count3);
      System.out.println("No of students in 00-40 range: "+count4);
    }
}
