import java.util.*;
public class Ch2Q28f 
{
 public static void main(String[] args) 
    {Scanner kbd = new Scanner(System.in);
     System.out.print("How many Armstrong Nos: ");
     int n = kbd.nextInt();
     int count = 0;
     for(int no = 1; count < n; no++)
	     if(armstrong(no))
	         {System.out.println(no+"  ");
	          count++;
	         }
     }
 static boolean armstrong(int no)
    {int sum = 0, no1 = no;
     while(no!=0)
          {int dig = no%10;
           sum += dig*dig*dig;
           no /= 10;
          }
     return(sum == no1);
    }
     
}