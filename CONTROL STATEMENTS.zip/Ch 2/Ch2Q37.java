import java.util.*;

public class Ch2Q37 
{
 public static void main(String[] args) 
 	{Scanner kbd = new Scanner(System.in);
 	 System.out.print("Enter n: ");
 	 int n = kbd.nextInt();
 	 double sum = 0;
 	 for(int i = 1; i <= n; i++)
 	 	 sum += 1.0/(i*i);
 	 System.out.println("Sum = "+sum);
        
    }
}
