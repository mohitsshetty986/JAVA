import java.util.*;
public class Ch2Q27f 
{
 public static void main(String[] args) 
    {Scanner kbd = new Scanner(System.in);
     System.out.print("Enter an integer: ");
     int n = kbd.nextInt();
     for(int no = 1; no < n; no++)
	    if(armstrong(no))
	       System.out.println(no+"  ");
     }
 static boolean armstrong(int no)
    {int sum = 0, no1 = no;
     while(no!=0)
          {int dig = no%10;
           sum += dig*dig*dig;
           no /= 10;
          }
     return(sum == no1);
    }
     
}