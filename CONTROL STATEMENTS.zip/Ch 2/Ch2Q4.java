import java.util.*;
public class Ch2Q4 
{
 public static void main(String[] args) 
    {Scanner kbd = new Scanner(System.in);
     System.out.print("Enter year: ");
     int yr = kbd.nextInt();
     if(yr<1582&&yr%4==0||yr%400==0||yr%4==0&&yr%100!=0)
     	System.out.println("Leap Year");
     else System.out.println("Not a Leap Year");
    }
}
