import java.util.*;
public class Ch2Q23 
{
 public static void main(String[] args) 
    {Scanner kbd = new Scanner(System.in);
     System.out.print("Enter the integer: ");
     int no = kbd.nextInt();
     int first = 0, second = 1, third = 1;
     while(third < no)
          {third = first + second;
           first = second;
           second = third;
          }
     if(third == no || no == 0)
     	System.out.println("Fibonacci No");
     else System.out.println("Not a Fibonacci No");
    }
}
