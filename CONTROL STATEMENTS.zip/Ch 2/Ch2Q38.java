import java.util.*;

public class Ch2Q38 
{
 public static void main(String[] args) 
 	{Scanner kbd = new Scanner(System.in);
 	 System.out.print("Enter n: ");
 	 int n = kbd.nextInt();
 	 double sum = 0;
 	 int sign = 1;
 	 for(int i = 1; i <= n; i++)
 	     {sum += sign*1.0/i;
 	 	  sign = -sign;
 	     }
 	 System.out.println("Sum = "+sum);
        
    }
}
