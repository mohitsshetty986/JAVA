import java.util.*;
public class Ch2Q30 
{
 public static void main(String[] args) 
    {Scanner kbd = new Scanner(System.in);
     double max, min;
     int count;
     System.out.print("Enter an integer: ");
     double no = kbd.nextDouble();
     if(no >= 0)
       {max = min = no;
        count = 1;
        System.out.print("Enter an integer: ");
        no = kbd.nextDouble();
        while(no >= 0)
             {if(no > max)
             	 max = no;
              else if(no < min)
              	      min = no;
              count++;
              System.out.print("Enter an integer: ");
     		  no = kbd.nextDouble(); 
             }
        System.out.println("Max = "+max);
        System.out.println("Min = "+min);
        System.out.println("Count = "+count);
       }
     else System.out.println("No Data");
    }
}
