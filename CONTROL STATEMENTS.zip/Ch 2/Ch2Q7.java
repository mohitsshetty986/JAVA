import java.util.*;
public class Ch2Q7 
{
 public static void main(String[] args) 
    {Scanner kbd = new Scanner(System.in);
     System.out.print("Enter sides of triangle: ");
     double a = kbd.nextDouble();
     double b = kbd.nextDouble();
     double c = kbd.nextDouble();
     if(a+b>c && b+c>a && c+a>b)
     	if(a==b&&b==c)
     	   System.out.println("Equilateral");
     	else if(a==b||b==c||a==c)
     		    System.out.println("Isosceles");
     		 else System.out.println("Scalene");
     else System.out.println("Triangle not possible");
    }
}
