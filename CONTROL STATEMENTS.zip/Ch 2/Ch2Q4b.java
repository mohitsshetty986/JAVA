import java.util.*;
public class Ch2Q4b 
{
 public static void main(String[] args) 
    {Scanner kbd = new Scanner(System.in);
     System.out.print("Enter year: ");
     short yr = kbd.nextShort();
     if(yr < 1582)
     	if(yr%4==0)
     	   System.out.println("Leap Year");
     	else System.out.println("Not a Leap Year");
     else if(yr%4==0)
     	     if(yr%100==0)
     	        if(yr%400==0)
     	           System.out.println("Leap Year");
     	        else System.out.println("Not a Leap Year");
     	     else System.out.println("Leap Year");
     	  else System.out.println("Not a Leap Year");
     
    }
}



