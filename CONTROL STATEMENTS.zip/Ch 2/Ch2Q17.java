public class Ch2Q17 
{
 public static void main(String[] args) 
 	{int i = 0, x = 0;
 	 for(i=1; i<10; ++i)
 	    {if(i%2==1)
 	    	x += i;
 	     else x--;
 	     System.out.println(x);
 	    }
     System.out.printf("\n x = %d", x);
    }
}
