import java.util.*;
public class Ch2Q21 
{
 public static void main(String[] args) 
    {Scanner kbd = new Scanner(System.in);
     System.out.print("Enter an integer: ");
     int no = kbd.nextInt();
     int rev = 0, count = 0;
     while(no!=0)
     {int dig = no % 10;
      rev = rev*10 + dig;
      no = no / 10;
      count++;
     }
     while(count != 0)
     {int dig = rev%10;
      System.out.print(dig+" ");
      rev = rev / 10;
      count--;
     }
    }
}
