class A
{private int a = 1;
 private void fa()
 	     {System.out.println("a = "+a); }
 int aa = 2;
 void faa()
      {fa(); System.out.println("aa = "+aa); }
 protected int aaa = 3;
 protected void faaa()
 	  {faa(); System.out.println("aaa = "+aaa); }
 public int aaaa = 4;
 public void faaaa()
 	    {faaa(); System.out.println("aaaa = "+aaaa); }
}

class B extends A
{private int b = 11;
 private void fb()
 	     {System.out.println("b = "+b); }
 int bb = 22;
 void fbb()
 	{System.out.println("bb = "+bb); }
 protected int bbb = 33;
 protected void fbbb()
 	       {System.out.println("bbb = "+bbb); }
 public int bbbb = 44;
 public void fbbbb()
 	    {System.out.println("bbbb = "+bbbb);}
}

class inhTesting
{public static void main(String [] args)
  {B x = new B();
   x.fbbbb();
  }
}