import java.util.*;
abstract class Shape
{double rad;
 public void getData()
 {System.out.print("Enter radius: ");
  Scanner kbd = new Scanner(System.in);
  rad = kbd.nextDouble(); 
 }
 abstract public void displayVol();
}

class Sphere extends Shape
{public void displayVol() 
{System.out.println("The volume is "+4*22*rad*rad*rad/7/3); }
}

class Hemisphere extends Shape
{public void displayVol() 
{System.out.println("The volume is "+2*22*rad*rad*rad/7/3); }
}

public class Ch5Q23
{public static void main(String[] args)
{Shape s;
 Scanner kbd = new Scanner(System.in);
 do{
 System.out.print("1 for sphere \n2 for hemisphere \n3 to quit\nEnter the choice: ");
 int choice = kbd.nextInt();
 if(choice == 1 )s = new Sphere ();
 else if(choice == 2)s = new Hemisphere ();
      else if(choice == 3)return;
           else continue; 
 s.getData(); 
 s.displayVol();
 }while(true);
}
}