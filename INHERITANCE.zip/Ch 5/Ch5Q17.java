class Rectangle
{protected double length, width;
 public Rectangle(double length, double width)
 {this.length = length; this.width = width;}
 public double area()
 {return length*width;}
}

class Box extends Rectangle
{double depth;
 public Box(double l, double w, double d)
 {super(l, w); depth = d; }
 public double area()
 {return 2*(length*depth+depth*width+width*length);}
 public double area1()
 {return 2*(length*depth+depth*width+super.area());}
 public double volume()
 {return length*depth*width;}
}

class Ch5Q17
{   public static void main(String[] args) 
    {Rectangle r = new Rectangle(10, 5);
     System.out.println("Area of Rectangle is "+r.area());
     Box b = new Box(4, 5, 6);
     System.out.println("Surface area of box is "+b.area());
     System.out.println("Surface area of box is "+b.area1());
     System.out.println("volume of box is "+b.volume());
    }
}
