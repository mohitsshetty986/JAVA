import java.util.*;
class Person
{private int code;
 private String name;
 public void read()
 {Scanner kbd = new Scanner(System.in);
  System.out.print("Enter name: ");
  name = kbd.nextLine();
  System.out.print("Enter code: ");
  code = kbd.nextInt();
 }
 public void display()
 {System.out.println("Code: "+ code);
  System.out.println("Name: "+ name);
 }
}
class Account extends Person
{private double pay;
 public void read()
 {Scanner kbd = new Scanner(System.in);
  super.read();
  System.out.print("Enter payment: ");
  pay = kbd.nextDouble();
 }
 public void display()
 {super.display();
  System.out.println("Payment: "+ pay);
 }
}
class Admin extends Account
{private int exp;
 public void read()
 {super.read();
  Scanner kbd = new Scanner(System.in);
  System.out.print("Enter experience: ");
  exp = kbd.nextInt();
 }
 public void display()
 {super.display();
  System.out.println("Experience: "+ exp); 
 }
}
public class Ch5Q13
{public static void main(String[] args)
 {Admin a = new Admin();
  a.read() ; 
  a.display(); 
 }
}