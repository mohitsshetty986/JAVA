import java.util.*;
abstract class Person 
{private String name;
 public void getdata()
 {System.out.print("Enter name: ");
  Scanner kbd = new Scanner(System.in);
  name = kbd.nextLine();
 }
 public void putname()
 {System.out.print("\nName : "+ name);}
 abstract public boolean isoutstanding();
}
class Student extends Person 
{protected double gpa;
 public void getdata()
 {Scanner kbd = new Scanner(System.in);
  super.getdata();
  System.out.print("Enter GPA: ");
  gpa = kbd.nextDouble();
 }
 public boolean isoutstanding()
 {return(gpa >= 8);}
}
class Professor extends Person 
{protected int publ;
 public void getdata()
 {Scanner kbd = new Scanner(System.in);
  super.getdata();
  System.out.print("Enter no of Publications: ");
  publ = kbd.nextInt();
 }
 public boolean isoutstanding()
 {return(publ >= 100);}
}
public class Ch5Q28
{ public static void main(String[] args)
{ Person [] p = new Person[5] ;
  Scanner kbd = new Scanner(System.in);
  int choice;
  for(int i = 0; i < 3; i++)
     {System.out.print("Enter 1 for student data 2 for Professor data: ");
      choice = kbd.nextInt();
      if(choice == 1) p[i] = new Student();
      else if(choice == 2)p[i] = new Professor();
           else {i--; continue;}
      p[i].getdata();
     }
     for(int i = 0; i < 3; i++)
        {p[i].putname(); // Display name (base class function) 
         if(p[i].isoutstanding()) // Display if outstanding 
            System.out.print("\tThis person is outstanding");
        }
}
}