import java.util.*;
class student
{int rno;
 public void read()
 {Scanner kbd = new Scanner(System.in);
  System.out.print("Enter Roll No: ");
  rno = kbd.nextInt();
 }
 public void display()
 {System.out.println("Roll No: "+ rno);}
}

class test extends student
{int marks1, marks2;
 public void read()
 {super.read();
  System.out.print("Enter Marks of two subjects: ");
  Scanner kbd = new Scanner(System.in);
  marks1 = kbd.nextInt(); marks2 = kbd.nextInt();
 }
 public void display()
 {super.display();
  System.out.println("Marks are "+marks1+" and "+ marks2);
 }	
}

interface sports 
{public void read_score();}

class result extends test implements sports
{int score, total;
 public void read_score()
 {Scanner kbd = new Scanner(System.in);
  System.out.print("Enter Score: ");
  score = kbd.nextInt(); 
 }
 public void read()
 {super.read();
  read_score();
  total = marks1 + marks2 + score;
 }
 public void display()
 {super.display();
  System.out.println("Score is "+score);
  System.out.println("Total is "+total);
 }	
}

public class Ch5Q35
{public static void main(String[] args)
 {result r;
  r = new result();
  r.read(); 
  r.display();
 }
}
