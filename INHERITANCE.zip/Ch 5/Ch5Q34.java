import java.util.*;
interface shape
{void readData();
 void displayArea();
}
class square implements shape
{private double side;
 public void readData()
  {Scanner kbd = new Scanner(System.in);
   System.out.print("Enter side of the square: ");
   side = kbd.nextDouble();
  }
 public void displayArea()
 {
  System.out.println("Area of square with side "+ side+" is "+side*side);
 }
}
class rectangle implements shape
{private double length, breadth;
 public void readData()
  {Scanner kbd = new Scanner(System.in);
   System.out.print("Enter sides of the rectangle: ");
   length = kbd.nextDouble();
   breadth = kbd.nextDouble();
  }
 public void displayArea()
 {
  System.out.println("Area of rectangle with sides "+ length +" and " +breadth+" is "+length*breadth);
 }
}

public class Ch5Q34 
{
        
  public static void main(String[] args) 
    {
     rectangle r = new rectangle();
     r.readData(); r.displayArea();
     square s = new square();
     s.readData(); s.displayArea();
    }
}
