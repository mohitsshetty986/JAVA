import java.util.*;
class Shape
{double x, y;
 public void readData()
 {System.out.print("Enter the dimensions: ");
  Scanner kbd = new Scanner(System.in);
  x = kbd.nextDouble(); y = kbd.nextDouble();
 }
 public void displayArea(){ }
}

class Rectangle extends Shape
{public void displayArea() 
{System.out.println("The area is "+x*y); }
}

class Triangle extends Shape
{public void displayArea() 
{System.out.println("The area is "+x*y/2); }
}

public class Ch5Q20
{public static void main(String[] args)
{Shape s;
 Scanner kbd = new Scanner(System.in);
 do{
 System.out.print("1 for triangle\n2 for rectangle\n3 to quit\nEnter the choice: ");
 int choice = kbd.nextInt();
 if(choice == 1 )s = new Triangle();
 else if(choice == 2)s = new Rectangle();
      else if(choice == 3)return;
           else continue; 
 s.readData(); 
 s.displayArea();
 }while(true);
}
}