import java.util.*;
class staff
{private int code;
 private String name, add;
 public void read()
 {Scanner kbd = new Scanner(System.in);
  System.out.print("Enter name: ");
  name = kbd.nextLine();
  System.out.print("Enter address: ");
  add = kbd.nextLine();
  System.out.print("Enter code: ");
  code = kbd.nextInt();
 }
 public void display()
 {System.out.println("Code: "+ code);
  System.out.println("Name: "+ name);
  System.out.println("Address: "+ add);
 }
}
class teacher extends staff
{private String subject;
 private int publications;
 public void read()
 {super.read();
  Scanner kbd = new Scanner(System.in);
  System.out.print("Enter subject: ");
  subject = kbd.nextLine();
  System.out.print("Enter No of publications: ");
  publications = kbd.nextInt();
 }
 public void display()
 {super.display();
  System.out.println("Subject: "+ subject);
  System.out.println("No of publicatiosn: "+ publications);
 }
}
class officer extends staff
{private String grade;
 public void read()
 {super.read();
  Scanner kbd = new Scanner(System.in);
  System.out.print("Enter grade: ");
  grade = kbd.nextLine();
 }
 public void display()
 {super.display();
  System.out.println("Grade: "+ grade);
 }
}
class typist extends staff
{private int speed;
 public void read()
 {super.read();
  System.out.print("Enter speed: ");
  Scanner kbd = new Scanner(System.in);
  speed = kbd.nextInt();
 }
 public void display()
 {super.display();
  System.out.println("Speed: "+speed);
 }	
}
class regular extends typist
{}
class casual extends typist
{private double dWages;
 public void read()
 {super.read();
  System.out.print("Enter daily wages: ");
  Scanner kbd = new Scanner(System.in);
  dWages = kbd.nextDouble();
 }
 public void display()
 {super.display();
  System.out.println("Daily wages: "+dWages);
 }	
}
public class Ch5Q14
{public static void main(String[] args)
 {regular r= new regular();
  r.read() ; r.display(); 
 }
}