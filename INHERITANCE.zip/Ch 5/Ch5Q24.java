import java.util.*;
abstract class account
{protected String name;
 protected int acNo;
 protected double amt;
 public account(){}
 public account(int acNo)
 {Scanner kbd = new Scanner(System.in);
  this.acNo = acNo;
  System.out.print("Enter Name: ");
  name = kbd.nextLine();
  System.out.print("Enter intial amount: ");
  amt = kbd.nextDouble();   
 }
 public void displayBal()
 {System.out.println("Account Balance = "+amt); }
 public void displayInfo()
 {System.out.println("\nName: "+name);
  if (this instanceof current_acct)
 	 System.out.println("Current Account");
  else System.out.println("Savings Account");
  System.out.println("Account No: "+acNo);
  System.out.println("Current Balance: "+amt);
 }
 public void acceptDeposit(double deposit) 
 {amt += deposit; }
 public boolean withdraw(double wamt)
 {if(amt >= wamt)
    {amt -= wamt; return true;}
  else return false;
 }
 abstract public void calculateInterest();
}

class current_acct extends account
{private static double minBalance = 500;
 private static double serviceCharge = 50;
 public current_acct(int acNo)
 {super(acNo); }
 public boolean withdraw(double wamt)
 {boolean status = super.withdraw(wamt);
  if(status)
  	if(amt < minBalance)
  	  {amt -= serviceCharge;
  	   System.out.println("Penalty for not keeping minimum balance = Rs "+minBalance);
  	   System.out.println("Penalty charged = "+serviceCharge);
  	  }
  return status;
 }
 public void calculateInterest()
 {System.out.println("Interest facility not for Current A/C");
 }
}

class savings_acct extends account
{static double rate = 10;
 public savings_acct(int acNo)
 {super(acNo); }
 public void calculateInterest()
 {System.out.println("Rate of interest is "+rate);
  System.out.print("For how many years to deposit: ");
  Scanner kbd = new Scanner(System.in);
  double n = kbd.nextDouble();
  double famt = amt * Math.pow(1+rate/100, n) - amt;
  System.out.printf("Interest you will earn on current balance = %8.2f\n",famt);
 }
}

public class Ch5Q24 
{
    public static void main(String[] args) 
    { Scanner kbd = new Scanner(System.in);
      int acno = 100;
      System.out.println("Which type of account you want?: ");
      System.out.println("Enter 1 for Savings account");
      System.out.println("Enter 2 for Current account"); 
      System.out.print("Enter your choice: "); 
      int type = kbd.nextInt();
      account ac;
      if (type ==1)
          ac = new savings_acct(acno++);
      else ac = new current_acct(acno++); 
      int choice;
      do
     {ac.displayInfo();
      System.out.println("\nBanking Operations");
      System.out.println("Enter 1 to deposit amount");
      System.out.println("Enter 2 to display balance");
      System.out.println("Enter 3 to withdraw amount");
      System.out.println("Enter 4 to calculate interest");
      System.out.println("Enter 5 to quit");
      System.out.print("Enter your choice:");
      choice = kbd.nextInt();
      switch(choice)
      {case 1: System.out.print("Enter deposit amount:");
      	       double depo = kbd.nextDouble();
      	       ac.acceptDeposit(depo); break;
       case 2: ac.displayBal(); break;
       case 3: System.out.print("Enter withdrawl amount:");
      	       double wamt = kbd.nextDouble();
      	       if(ac.withdraw(wamt))
      	       	 System.out.println("Amount withdrawn");
      	       else System.out.println("Not enough money");break;
       case 4: ac.calculateInterest();
               System.out.println("Contact Bank Manager for details");
      }
     }while(choice != 5);
    }
}

