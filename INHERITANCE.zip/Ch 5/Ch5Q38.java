import java.util.*;
abstract class Shape
{double x, y, z;
 abstract public void readData();
 abstract public void displayArea();
}
class Circle extends Shape
{public void readData()
 {System.out.print("Enter the radius: ");
  Scanner kbd = new Scanner(System.in);
  x = kbd.nextDouble(); 
 }
 public void displayArea() 
{System.out.println("The area of circle is "+Math.PI*x*x); }
}
class Rectangle extends Shape
{public void readData()
 {System.out.print("Enter the sides of the rectangle: ");
  Scanner kbd = new Scanner(System.in);
  x = kbd.nextDouble(); 
  y = kbd.nextDouble();
 }
 public void displayArea() 
{
 System.out.println("The area of rectangle is "+x*y); }
}
class Triangle extends Shape
{public void readData()
 {System.out.print("Enter the sides of the triangle: ");
  Scanner kbd = new Scanner(System.in);
  x = kbd.nextDouble(); 
  y = kbd.nextDouble();
  z = kbd.nextDouble();
 }
 public void displayArea() 
{double s = (x+y+z)/2;
 double area = Math.sqrt(s*(s-x)*(s-y)*(s-z));
 System.out.println("The area of triangle is "+area); }
}
public class Ch5Q38
{public static void main(String[] args)
{Shape s;
 Scanner kbd = new Scanner(System.in);
 do{
 System.out.print("1 for triangle\n2 for rectangle\n");
 System.out.print("3 for circle\n4 to quit\nEnter the choice: ");
 int choice = kbd.nextInt();
 if(choice == 1 )s = new Triangle();
 else if(choice == 2)s = new Rectangle();
      else if(choice == 3)s = new Circle();
           else if(choice == 4)return;
                else continue; 
 s.readData(); 
 s.displayArea();
 }while(true);
}
}