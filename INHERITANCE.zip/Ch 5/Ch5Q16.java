class A
{protected int a, aa;
 public A(int z){aa = z;}
 public A(){aa = 1;}
 public void display()
 {System.out.println("a =  "+a+"\naa = "+aa);
 }
}

class B extends A
{protected int b, bb;
 public B(int n)	
         {b = n; bb = n + 1;}
 public void display()
 {super.display();
  System.out.println("b =  "+b+"\nbb = "+bb);
 }         
}

class C extends B
{ protected int c;
  public C(int n){super(n); c = n + 2; }
  public void display()
 {super.display();
  System.out.println("c =  "+c);
 }
}

public class Ch5Q16
{public static void main(String[] args)
{C x;
  x = new C(2);
  x.display();
}
}

