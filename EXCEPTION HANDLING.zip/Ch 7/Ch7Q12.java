class Exception1
{public static void main(String args[ ])
 {int c = 0;
  int a = 5, b = 0;
  c = a/b;
  System.out.println("Statement After Exception");
  System.out.println("Answer = "+c);
  System.out.println("End of the Program");
 }
}
