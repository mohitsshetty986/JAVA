class Ch7Q3 
{
 public static void main(String[] args) 
 	{int a = Integer.parseInt(args[0]);
     int b = Integer.parseInt(args[1]);
     int c = Integer.parseInt(args[2]);   
     int d = a>b?a:b;
     int max = d>c?d:c;
     System.out.println("Maximum = "+max);
    }
}
