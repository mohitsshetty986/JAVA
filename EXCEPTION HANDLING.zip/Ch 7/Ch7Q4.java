class Ch7Q4 
{
 public static void main(String[] args) 
 	{int no = Integer.parseInt(args[0]);
 	 int sum = 0, no1 = no;
     while(no!=0)
          {int dig = no %10;
           no = no /10;
           sum += dig*dig*dig;
          }
     if(sum==no1)
        System.out.println("Armstrong No");
     else System.out.println("Not an Armstrong No");
    }
}
