//try - catch
class Exception2
{public static void main(String args[ ])
 {int a=5, b=0, c=0;
  try
     {
      c=a/b;
      System.out.println ("Statement After Exception");
     }
  catch (ArithmeticException e)
     {System.out.println("Exception caught = "+e);
      c=100;
     }
  System.out.println ("Answer = "+c);
  System.out.println ("End of the Program");
 }
}
