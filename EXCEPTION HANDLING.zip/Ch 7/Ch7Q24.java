//Demo Exception 
import java.io.*;
class Demo extends Exception
{int num;
 public Demo(int k) {num = k;}
 public String toString( )
 {return "Exception:java.lang.Demo:For input String: \""
 	      +num+"\"";}
}

class PositiveInteger
{public void check(int k)throws Demo
  {if (k>0)
       System.out.println("Success for "+k);
   else throw new Demo(k);
  }
}

class Exception10
{public static void main(String args[ ])
{   BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
   System.out.print("Enter a positive integer: ");
   try
   {
   int n = Integer.parseInt(br.readLine());
   PositiveInteger a = new PositiveInteger( );
   a.check(n);
   }
  catch(IOException e)
  {
  	System.out.println("Exception caught: "+e);
  }
  catch(Demo e)
  {
  	System.out.println("Exception caught: "+e);
  }
 System.out.println("End of the program");
 }
}

