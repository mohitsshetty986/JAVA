public class Ch7Q3a
{
 static public void main(String args[])
 {
  int a = Integer.parseInt(args[0]);
  int b = Integer.parseInt(args[1]);
  int c = Integer.parseInt(args[2]);
  int max = (a>b?a:b)>c?(a>b?a:b):c;
  System.out.println("Max = "+max);
 }
}
