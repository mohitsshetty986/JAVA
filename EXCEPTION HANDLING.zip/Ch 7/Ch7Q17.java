//try - catch - finally
import java.util.*;
class Exception7
{public static void main(String args[ ])
 {try{int a=args.length;
      System.out.println("a = "+a); 
      int c=20/a; return;
      }
  catch(ArithmeticException e)
     {System.out.println("Exception caught: "+e);
      System.out.println("Ans = 100");
     }
    finally
     {System.out.println("Finally Block");
      System.out.println("Can be used to complete pending tasks");
     }
  System.out.println("End of the Program");
 }
}
