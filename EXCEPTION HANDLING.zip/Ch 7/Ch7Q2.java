//import java.io.*;
public class Ch7Q2 
{public static void main(String[] args) //throws IOException 
    {int a = Integer.parseInt(args[0]);
     int b = Integer.parseInt(args[1]);
     int small = a <b ? a : b;
     while(a%small != 0 || b%small !=0)small--;
     System.out.println("GCD = "+small);   
    }
}
