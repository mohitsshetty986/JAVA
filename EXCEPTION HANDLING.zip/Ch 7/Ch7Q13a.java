//array exception
class Exception4
{public static void main(String args[ ])
 {int a[ ]={31,82,37,44,78};
  try{
      for (int i=0; i<=7; i++)
           System.out.print (a[i] + " ");
     }
  catch (Exception t)
     {
       System.out.println ("\nException caught = "+t);
     }
  System.out.println ("End of the Program");
 }
}
