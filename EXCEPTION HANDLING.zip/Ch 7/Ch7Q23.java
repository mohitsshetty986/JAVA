// BufferedReader without throws 
import java.io.*;
class Exception10
{public static void main(String args[ ])throws IOException
 {InputStreamReader isr = new InputStreamReader(System.in);
  BufferedReader br = new BufferedReader(isr);  
  System.out.print("Enter the marks: ");
  int a = Integer.parseInt(br.readLine());
       if (a>100 || a<0) 
           {Exception t= new Exception("Marks out of range");
            throw t;
           }
       else System.out.println("Marks = "+a);
 }
}
