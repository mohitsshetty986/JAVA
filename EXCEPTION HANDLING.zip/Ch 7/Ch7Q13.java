//array exception
class Exception3
{
 public static void main(String args[ ])
 {
    int a[ ]={31,82,37,44,78};
    
    for (int i=0; i<=7; i++)
    try{  
    	System.out.print (a[i] + " ");
       }
    catch(ArrayIndexOutOfBoundsException e)
    {System.out.println(e);
    }
	System.out.println ("End of the Program");
 }
}
