class Ch7Q5 
{
 public static void main(String[] args) 
    {
     int a = Integer.parseInt(args[0].trim());
     char oper = args[1].trim().charAt(0);
     int b = Integer.parseInt(args[2].trim());
     switch(oper)
     {case '+' : System.out.println("ans = "+(a+b)); break;
      case '-' : System.out.println("ans = "+(a-b)); break;
      case '*' : System.out.println("ans = "+(a*b)); break;
      case '/' : System.out.println("ans = "+(a/b)); break;
      default  : System.out.println("wrong operator");
     }
    }
}
