//throw
class Exception8
{public static void main(String args[ ])
 {int a = 2, b = 0,c;
  try
  {if(b==0)
     {Exception t = new Exception("SampleException");
      throw t;
     }
   else c = a/b;
   System.out.println("Answer  = "+c);
  }
  catch(Exception e)
  {
   System.out.println("Exception caught = "+e);
  }
  System.out.println("End of the Program");
 }
}
