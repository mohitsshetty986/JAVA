import java.util.*;
public class Ch7Q6a 
{public static void main(String[] args) 
 	{Vector <String> v = new Vector  <String> ();
 	 int count = args.length;
 	 for(int i = 0; i < count; i++)
 	 	v.add(args[i]);
 	 String[] ss = (String[])v.toArray(new String[v.size()]); 
 	 for(int i = 0; i < ss.length; i++)
        System.out.println(ss[i]);
     for(int i = 1; i < ss.length; i++)
     	for(int j = 0; j < ss.length-i; j++)
     		if(ss[j].compareTo(ss[j+1]) > 0)
     		  {String temp;
     		   temp = ss[j];
     		   ss[j] = ss[j+1];
     		   ss[j+1] = temp;
     		  }
     System.out.println("The sorted list:");
     for(int i = 0; i < ss.length; i++)
        System.out.println(ss[i]);    		  
    }
}

