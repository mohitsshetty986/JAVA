//our exception class MyException 
class MyException extends Exception{ }

class Exception9
{
 public static void main(String args[ ])
 {
  int a=2,b=0,c;
  try
  {if (b==0)
      {MyException t = new MyException ( );
       throw t;
      }
   else c=a/b;
   System.out.println ("Answer = "+c);
  }
  catch(MyException e)
  {
   System.out.println ("Exception caught = "+e);
  }
  System.out.println("End of the Program");
 }
}
