import java.util.*;
public class Ch7Q25 
{
  public static void main(String[] args) 
    {
     Scanner kbd = new Scanner(System.in);
     System.out.print("Enter values of a, b, c and d: ");
     double a = kbd.nextDouble();
     double b = kbd.nextDouble();
     double c = kbd.nextDouble();
     double d = kbd.nextDouble();
     if(b*d == 0)
        try
          {
     	    throw new Exception("b*dIsZeroException");
          }
        catch(Exception e)
        {System.out.println(e);
        }
     else System.out.println("Answer = "+ (a*d+b*c)/(b*d));
    }
}
