//multiple catch
import java.util.*;
class Exception5
{public static void main(String args[ ])
 {try{Scanner kbd = new Scanner(System.in);
      System.out.print("Enter n: "); 
      int n = kbd.nextInt();
      int c=20/n;
      int ar[ ]={1};
      ar[10]=20;
     }
  catch (Exception t)
     { System.out.println("Catch Block 3");
       System.out.println ("\nException caught = "+t);
     }
  catch (ArithmeticException t)
     { System.out.println("Catch Block 1");
       System.out.println ("\nException caught = "+t);
     }
  
  catch (ArrayIndexOutOfBoundsException t)
     { System.out.println("Catch Block 2");
       System.out.println ("\nException caught = "+t);
     }
  
  System.out.println("End of the Program");
 }
}
