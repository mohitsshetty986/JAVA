//nested try-catch
class Exception6
{public static void main(String args[ ])
 {try
  {int a=args.length;
   System.out.println("a = "+a);
   int c=20/a;
      try
        {if (a==1)
            {int z= a/(a-a);
             System.out.println("z = "+z);
            }
         if (a==2)
            {int k[ ]={1};
             k[30]=5;
            }
        }
      catch(ArithmeticException t)
          {System.out.println("Inner Catch Block");
           System.out.println("Exception caught = "+t);
          }
  }
  catch(ArrayIndexOutOfBoundsException t)
       {System.out.println("Outer Catch Block");
        System.out.println("Exception caught = "+t);
       }
  System.out.println("End of the Program");
 }
}
