import java.util.*;
public class Ch7Q6 
{public static void main(String[] args) 
 	{Vector <String> v = new Vector  <String> ();
 	 int count = args.length;
 	 for(int i = 0; i < count; i++)
 	 	v.add(args[i]);
 	 Collections.sort(v);
 	 for(int i = 0; i < count; i++)
        System.out.println(v.elementAt(i));
    }
}

