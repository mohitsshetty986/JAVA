//threads using Runnable interface
class MyRunnable implements Runnable 
{  public void run() 
   	{ System.out.println("Child thread started");       //   	  try{Thread.sleep(5000);}catch(Exception e){ 	  }
      System.out.println("Table Started");
      printTable();
      System.out.println("Table Over");
      System.out.println("Child thread terminated");
    }
    void printTable()
    {printLine();
     for(int i = 1; i <= 10; i++)
     	System.out.println("\t\t"+i+"\t\t"+(2*i));
     printLine();
    }
    void printLine()
    {System.out.println("Line Started");
     for(int i = 1; i<= 25; i++)
    	System.out.print("-");
     System.out.println();
     System.out.println("Line Over");
    }
}
class Demo 
{public static void main (String args[])throws InterruptedException
   	{ System.out.println("Main thread started Z"); 
      MyRunnable r = new MyRunnable();
      Thread t = new Thread(r);
      t.start(); 	Thread.sleep(10);
      for(int i = 1; i <= 10; i++)
      	  System.out.println(i);								//
      //Thread.sleep(10);								
      System.out.println("Main thread terminated");
    }
}





