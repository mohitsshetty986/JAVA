// threads using Thread class inheritance

class MyThread extends Thread 
{ public void run() 
   	{ System.out.println("Child thread started"); 
      System.out.println("Child thread terminated");
    }
}
class Demo 
{public static void main (String args[])//throws Exception 
   	{ System.out.println("Main thread started");
   	  MyThread child = new MyThread();
      child.start(); //Thread.sleep(10);
	  System.out.println("Main thread terminated");													
      
   }
}
