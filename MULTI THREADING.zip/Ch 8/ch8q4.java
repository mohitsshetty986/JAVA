class MyRunnable implements Runnable 
{ int init, fin, delay;
  MyRunnable (int init, int fin, int delay) 
  {  this.init = init;
     this.fin = fin;
     this.delay = delay;
  }
  public void run() 
    {for(int i = init; i <= fin; i++)
  	    {System.out.println(i);
  	     try {Thread.sleep(delay);} 
  	     catch (InterruptedException e) {}
  	    }  
  	  System.out.println("Thread Terminated");
    }
}
class Demo 
{public static void main (String args []) throws Exception
   {  MyRunnable r1 = new MyRunnable(1, 10, 200);
      MyRunnable r2 = new MyRunnable(11, 20, 350);
      MyRunnable r3 = new MyRunnable(21, 30, 125);
      Thread x = new Thread(r1); 
      Thread y = new Thread(r2); 
      Thread z = new Thread(r3); 
      //x.setDaemon(true); y.setDaemon(true);z.setDaemon(true);
      x.start(); y.start(); z.start();
      //Thread.sleep(3000);
      try{Thread.sleep(350);}catch(Exception e){}
      //System.out.println("Thread x is alive is "+x.isAlive());
      //System.out.println("Thread y is alive is "+y.isAlive());
      //System.out.println("Thread z is alive is "+z.isAlive());
      //try {x.join();} catch (InterruptedException e) {}
      //try {y.join();} catch (InterruptedException e) {}
      //try {z.join();} catch (InterruptedException e) {}
      //System.out.println("Thread x is alive is "+x.isAlive());
      //System.out.println("Thread y is alive is "+y.isAlive());
      //System.out.println("Thread z is alive is "+z.isAlive());
      System.out.println("Main Terminated");
   }
}
