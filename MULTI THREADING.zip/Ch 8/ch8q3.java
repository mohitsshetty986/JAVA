//threads using Runnable interface
class MyRunnable implements Runnable 
{  public void run() 
   	{ System.out.println("Child thread started");       
      for(int i = 11; i <= 200; i++)
      	  System.out.println(i);
   	  //try{Thread.sleep(5000);}catch(Exception e){ 	  }
   	  System.out.println("Child thread terminated");
    }
   
}
class Demo 
{public static void main (String args[])throws Exception 
   	{ System.out.println("Main thread started"); 
   	  MyRunnable r = new MyRunnable();						
   	  Thread child = new Thread(r);
   	  //child.setDaemon(true);
      child.start(); 	
      for(int i = 1; i <= 10; i++)
      	  System.out.println(i);
      //Thread.sleep(10000);
      System.out.println("Main thread terminated");
    }
}





