class Ch8q0
{  public static void main(String[] args) 
    {
     Thread t = Thread.currentThread();
     System.out.println("Current thread: " + t);
     t.setName("Demo Thread");
     System.out.println("Renamed Thread: " + t);
    }
}
