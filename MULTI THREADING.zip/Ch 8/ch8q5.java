class A extends Thread
{public void run()
 {for(char ch = 'a'; ch <= 'z'; ch++)
     {System.out.print(ch+" ");
      try{Thread.sleep(10);}
      catch(Exception e){}
     }
 }
}

class B extends Thread
{public void run()
 {for(int i = 1; i <= 26; i++)
     {System.out.print(i+" ");
      try{Thread.sleep(10);}
      catch(Exception e){}
     }
 }
}


class IsAliveJoin
{
 public static void main(String[] args)throws Exception
 	{A x = new A();
 	 B y = new B();
     x.start(); y.start(); 
     if(x.isAlive())x.join();   
     if(y.isAlive())y.join();   
     System.out.println("\nMain Terminated");
    }
}
