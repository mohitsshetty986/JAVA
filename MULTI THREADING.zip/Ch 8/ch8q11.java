class A extends Thread
{public void run()
 {for(int i = 1; i <= 10; i++)
     {System.out.print("a ");
      try{Thread.sleep(10);}
      catch(Exception e){}
     }
 }
}

class B extends Thread
{public void run()
 {for(int i = 1; i <= 10; i++)
     {System.out.print("b ");
      try{Thread.sleep(10);}
      catch(Exception e){}
     }
 }
}

class C extends Thread
{public void run()
 {for(int i = 1; i <= 10; i++)
     {System.out.print("c ");
 	  try{Thread.sleep(10);}
      catch(Exception e){}
     }
 }
}

class IsAliveJoin
{
 public static void main(String[] args)throws Exception
 	{A x = new A();
 	 B y = new B();
 	 C z = new C();
 	 x.setDaemon(true);y.setDaemon(true);z.setDaemon(true);
     x.start(); y.start(); z.start();
     if(x.isAlive())x.join();   
     if(y.isAlive())y.join();   
     if(z.isAlive())z.join();   
     Thread.sleep(10000);
     System.out.println("\nMain Terminated");
    }
}
