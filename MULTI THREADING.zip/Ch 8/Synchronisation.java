class Xprinter
{//synchronized 
  public void printName(String firstName,
  	                    String secondName, 
  	                    long delay)
  {     System.out.print(firstName);         
        try {Thread.sleep(delay);}
        catch(InterruptedException e){}
        System.out.print(secondName + "\n"); 
  }
}

class TryThread extends Thread 
{ Xprinter nm;
  private String firstName;
  private String secondName;
  private long aWhile;
  public TryThread(Xprinter target, String firstName, 
  	               String secondName, long delay) 
  	{
  	nm = target ;
    this.firstName = firstName;     
    this.secondName = secondName;
    aWhile = delay;
    setDaemon(true);
    }
    public void run()
    { while(true)    									
    	synchronized(nm)
       	{nm.printName(firstName, secondName, aWhile);}
    }
}
  
class Demo
{public static void main(String[] args) throws InterruptedException
  {	Xprinter t = new Xprinter();
    // Create three threads
    TryThread first = new TryThread
    	              (t, "Sachin ", "Tendulkar ", 200L);
    TryThread second = new TryThread
    	              (t, "Amitabh ", "Bachchan ", 200L);
    TryThread third = new TryThread
    	              (t, "Sonia ", "Gandhi ", 200L);
    first.start(); second.start(); third.start();
    Thread.sleep(20000L);
    System.out.println("Ending main()");
  }
}
