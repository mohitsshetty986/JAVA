class MyRunnable implements Runnable 
{int init, fin, delay;
  MyRunnable (int init, int fin, int delay) 
  {  this.init = init;
     this.fin = fin;
     this.delay = delay;
  }
  
public void run() 
    {for(int i = init; i <= fin; i++)
  	    {System.out.println(i);
  	     try {Thread.sleep(delay);} 
  	     catch (InterruptedException e) {}
  	    }  
  	 System.out.println(Thread.currentThread().getName()+" Thread Terminated");
    }
}
 
class Ch8Q12 
{public static void main (String args []) throws InterruptedException 
   {  MyRunnable r1 = new MyRunnable(1, 10, 100); 
      MyRunnable r2 = new MyRunnable(11, 20, 100);
      MyRunnable r3 = new MyRunnable(21, 30, 100);
      Thread x = new Thread(r1); x.setPriority(1);
      Thread y = new Thread(r2); y.setPriority(10);
      Thread z = new Thread(r3); z.setPriority(5);
      x.setName("First");y.setName("Second");z.setName("Third");
      System.out.println(x.getName()+" has priority "+ x.getPriority());
      System.out.println(y.getName()+" has priority "+ y.getPriority());
      System.out.println(z.getName()+" has priority "+ z.getPriority());
      x.start(); y.start(); z.start();
      if(x.isAlive())x.join();
      if(y.isAlive())y.join();
      if(z.isAlive())z.join();
       //try {Thread.sleep(4000);} 
  	     //catch (InterruptedException e) {}
      System.out.println("Main Terminated");
   }
}
