import java.awt.*;
import java.applet.*;

public class Face extends Applet
{public void init()
    {//setBackground(Color.yellow);
    }
	public void paint(Graphics g)
	{	//g.setColor(Color.red);
		g.drawOval(40, 40, 120, 150); //Head
		try {Thread.sleep(1000);} catch (InterruptedException e) {}
		g.drawOval(57, 75, 30, 20);  //Left eye
		g.drawOval(110, 75, 30, 20);  //Right eye
		try {Thread.sleep(1000);} catch (InterruptedException e) {}		
		g.fillOval(68, 81, 10, 10);   //Left pupil
		g.fillOval(121, 81, 10, 10);  //Right pupil
		try {Thread.sleep(1000);} catch (InterruptedException e) {}		
		g.drawOval(85, 100, 30, 30);  //Nose
		g.fillArc(60, 125, 80, 40, 180, 180); // Mouth
		try {Thread.sleep(1000);} catch (InterruptedException e) {}		
		g.drawOval(25, 92, 15, 30);   //Left ear
		g.drawOval(160, 92, 15, 30);  //Right ear
		try {Thread.sleep(1000);} catch (InterruptedException e) {}		
		g.drawArc(50, 70, 45, 35, 0, 180); //Left eyebrow
		g.drawArc(105, 70, 45, 35,  0, 180); //Right eyebrow
		g.setColor(Color.red);
		g.fillRect(55, 20, 90, 45);      // Cap
	}
}