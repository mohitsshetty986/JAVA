import java.applet.*;    
import java.awt.*; 

public class RectangleApplet extends Applet 
{
  public void paint(Graphics g) 
{   setBackground(Color.red);
    g.drawRect(15, 15, this.getSize().width - 30, 
    	               this.getSize().height - 30);
 }
}
