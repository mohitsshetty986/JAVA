import java.applet.*;
import java.awt.*;
public class Bullseye extends Applet 
{ public void paint(Graphics g) 
  { int appletHeight = this.getSize().height;
    int appletWidth = this.getSize().width;
    for (int i=8; i > 0; i--) 
    	{if ((i % 2) == 0) 
    		g.setColor(Color.white);
         else g.setColor(Color.black);
      // Center the rectangle
         int rectHeight = appletHeight*i/8;
         int rectWidth  = appletWidth*i/8;
         int rectLeft   = appletWidth/2  - i*appletWidth/16;
         int rectTop    = appletHeight/2 - i*appletHeight/16;
         try {Thread.sleep(1000);} 
         catch (InterruptedException e) {}
         g.fillOval(rectLeft, rectTop, rectWidth, rectHeight);
        }
  }
}
