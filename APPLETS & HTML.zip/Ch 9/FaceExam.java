import java.awt.*;
import java.applet.*;

public class FaceExam extends Applet
{
	public void paint(Graphics g)
	{
		g.drawOval(50, 75, 30, 20);    //Left eye
		g.drawOval(110, 75, 30, 20);   //Right eye
		g.drawLine(95, 95, 95, 130);  //Nose
		g.drawLine(75, 150, 115, 150); //Mouth
	}
}