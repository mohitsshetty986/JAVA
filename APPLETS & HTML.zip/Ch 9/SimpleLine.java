import java.applet.*;    
import java.awt.*; 

public class SimpleLine extends Applet 
{

 public void paint(Graphics g) 
 	{setBackground(Color.yellow);
     g.drawLine(0, 0, getSize().width, getSize().height);
    }

}
