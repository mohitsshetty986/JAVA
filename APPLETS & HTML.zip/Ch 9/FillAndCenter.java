import java.applet.*;    
import java.awt.*; 

public class FillAndCenter extends Applet 
{
  public void paint(Graphics g) 
 {
    int appletHeight = this.getSize().height;
    int appletWidth  = this.getSize().width;
    int rectHeight   = appletHeight/3;
    int rectWidth    = appletWidth/3;
    int rectTop      = (appletHeight - rectHeight)/2;
    int rectLeft     = (appletWidth - rectWidth)/2;
    g.setColor(Color.black);
    g.fillRect(rectLeft, rectTop, rectWidth, rectHeight);
 }
}
