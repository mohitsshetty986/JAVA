import java.awt.*;
import java.applet.*;
public class Polygon extends Applet
{
	public void paint(Graphics g)
	{int[] xpoints = {10, 180, 100, 0};
	 int[] ypoints = {0, 10, 190, 90};
	 g.setColor(Color.red);
	 //g.drawPolyline(xpoints, ypoints, 4);
	 //g.drawPolygon(xpoints, ypoints, 4);
	 g.fillPolygon(xpoints, ypoints, 4);
	 
	}
}
