import java.util.*;

class IntNos
{private int a, b;
 public void read()
 {Scanner kbd = new Scanner(System.in);
  System.out.print("Enter two integers: ");
  a = kbd.nextInt();
  b = kbd.nextInt();
 }
 public void addDisp()
 {System.out.println("Addition = "+(a+b));
 }
 public int subtract()
 {return a-b;
 }
 public void multDisp()
 {System.out.println("Multiplication = "+(a*b));
 }
 public double divide()
 {return (double)a/b;
 }
 public void display()
 {System.out.println("a = "+a+"\tb = "+b);
  System.out.println("Subtraction = "+subtract());
  multDisp();
 }
}
public class Ch4Q7 
{
 public static void main(String[] args) 
 	{IntNos x = new IntNos();
 	 x.read();
     x.display();
     x.addDisp();
     System.out.println("Division = "+x.divide());
    }
}
