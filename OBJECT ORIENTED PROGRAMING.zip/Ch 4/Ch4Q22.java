import java.util.*;
class student
{private int idNo, marks[];
 private String name;
 public void readData()
 {Scanner kbd = new Scanner(System.in);
  System.out.print("Enter name: ");
  name = kbd.nextLine();
  System.out.print("Enter idno: ");
  idNo = kbd.nextInt();
  marks = new int[4];
  System.out.print("Enter 3 marks: ");
  for(int i = 0; i< 3; i++)
      {marks[i] = kbd.nextInt();
       marks[3] += marks[i];
      }
 }
 static void sort(student [] s)
 {for(int i = 0; i < s.length-1; i++)
 	 for(int j = i+1; j < s.length; j++)
 	 	 if(s[j].marks[3] > s[i].marks[3])
 	 	    {student temp = s[i];
 	 	     s[i] = s[j];
 	 	     s[j] = temp;
 	 	    }
 }
 public void printData()
 {System.out.print("\n"+idNo+"\t");
  System.out.print(name+"\t");
  for(int i = 0; i < 4; i++)
      System.out.print(marks[i]+"\t");
 }
}

public class Ch4Q22 
{ public static void main(String[] args) 
 	{Scanner kbd = new Scanner(System.in);
 	 System.out.print("Enter no of students: ");
 	 int n = kbd.nextInt();
 	 student s[] = new student[n];
 	 for(int i = 0; i < n; i++)
 	     {s[i] = new student();
 	      s[i].readData();
 	     }
 	 student.sort(s);			//static function call
     for(int i = 0; i < n; i++)
 	 	 s[i].printData();
    }
}
