class complex
{private double real, imag;
 public complex(){ }
 public complex(double real, double imag)
 {this.real = real; this.imag = imag; }
 public complex(double real)
 {this(real, 5.5); }
 public complex(complex z)
 {real = z.real; imag = z.imag; }
 void display()
 {System.out.println(real+"+"+imag+"i"); }
 boolean equals (complex z)
 {return (real==z.real&&imag==z.imag);
 }  
}
public class Ch4Q16 
{public static void main(String[] args) 
 {complex a = new complex();
  complex b = new complex(1.1);
  complex c = new complex(1.1, 2.2);
  complex d = new complex(c);
  a.display();
  b.display();
  c.display();
  d.display();
  System.out.println(c==d);
  System.out.println(c.equals(d));
 }
}
