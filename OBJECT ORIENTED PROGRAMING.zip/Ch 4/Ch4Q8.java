import java.util.*;
class BankAcc
{private String name;
 private int accNo;
 private String type;
 private double balance;
 public void initialise()
 {Scanner kbd = new Scanner(System.in);
  System.out.print("Enter name: ");
  name = kbd.nextLine();
  System.out.print("Enter Account No: ");
  accNo = kbd.nextInt();
  System.out.print("Enter type of account: ");
  type = kbd.nextLine();
  type = kbd.nextLine();
  System.out.print("Enter amount: ");
  balance = kbd.nextDouble();
 }
 public void deposit(double amt)
 {balance += amt;
 }
 public boolean withdraw(double amt)
 {if(balance < amt )return false;
  balance -= amt;
  return true;
 }
 public void display()
 {System.out.println("Name: "+name);
  System.out.println("Balance: "+balance);
 }
}
public class Ch4Q8 
{
 public static void main(String[] args) 
    {BankAcc b = new BankAcc();
     b.initialise();
     b.deposit(500);
     if(b.withdraw(1000))
     	System.out.println("Amt withdrawn");
     else System.out.println("Insufficient Funds");
     b.display();
    }
}
