import java.util.*;
class A
{private int a, b, c;
 private static int count;
 public A(int a, int b, int c)
 	      {this.a = a;
 	       this.b = b; 
 	       this.c = c;
 	       count++;
 	      }
 public A (int a, int b){this(a, b, 30); }
 public A (int a){this(a, 20, 30); }
 public A (){this(10, 20, 30); }
 public void display()
 {
 	System.out.println("a = "+a+"\tb = "+b+"\tc = "+c+"\tcount = "+count);
 }
 public static void displayCount()
 {
 	System.out.println("count = "+count);
 }
}
public class Ch4Q18 
{
    public static void main(String[] args) 
    {A.displayCount();
     A x = new A();
     x.display();
     A y = new A(1);
     y.display();
     A z = new A(1, 2);
     z.display();
     A u = new A(1, 2, 3);
     u.display();   
     A.displayCount();
    }
}
