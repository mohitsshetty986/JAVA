import java.util.*;

class British
{private int ft;
 private double inch;
 public void read()
 {
  Scanner kbd = new Scanner(System.in);
  System.out.print("Enter distance in fts and inches: ");
  ft = kbd.nextInt();
  inch = kbd.nextDouble();
 }
 public void display()
 {
  System.out.println(ft+" fts and "+inch+" inches");
 }
 public British(){ }
 public British(int ft, double inch)
 {this.ft = ft; this.inch= inch; }
 public int getft()
 {return ft; }
 public double getinch()
 {return inch; }
 static Metric add(Metric m, British b)
    {double totcm = m.getmt()*100 + m.getcm()
    	           +(b.getft()*12+b.getinch())*2.54;
     return new Metric((int)(totcm/100), totcm %100);
    }
}

class Metric
{private int mt;
 private double cm;
 public void read()
 {Scanner kbd = new Scanner(System.in);
  System.out.print("Enter distance in mts and cms: ");
  mt = kbd.nextInt();
  cm = kbd.nextDouble();
 }
 public void display()
 {System.out.printf("%d mts and %6.2f cms\n", mt, cm);
 }
 public Metric(){ }
 public Metric (int mt, double cm)
 {this.mt = mt; this.cm = cm; }
 public int getmt()
 {return mt; }
 public double getcm()
 {return cm; }
 public Metric add(British b)
 {double totcm = mt*100+cm + (b.getft()*12+b.getinch())*2.54;
  int mts = (int)(totcm /100);
  double cms = totcm % 100;
  return new Metric(mts, cms);
 }
 public void add(Metric m, British b)
 {double totcm = m.mt*100+m.cm + (b.getft()*12+b.getinch())*2.54;
  mt = (int)(totcm /100);
  cm = totcm % 100;
 }
 public void add(British b, Metric ans)
 {double totcm = mt*100+cm + (b.getft()*12+b.getinch())*2.54;
  ans.mt = (int)(totcm /100);
  ans.cm = totcm % 100;
 }
 public static void add(Metric m, British b, Metric ans)
    {double totcm = m.mt*100 + m.cm
    	           +(b.getft()*12+b.getinch())*2.54;
     ans.mt = (int)(totcm/100);
     ans.cm = totcm %100;
    }
}

public class Ch4Q21
 
{public static void main(String[] args) 
 	{Metric m = new Metric();
 	 m.read();
 	 m.display();
 	 British b = new British(5, 10);
 	 b.display();

     Metric ans = m.add(b);
     ans.display();

     Metric ans1 = new Metric();
     ans1.add(m, b);
     ans1.display();

     Metric ans2 = new Metric();
     m.add(b, ans2);
     ans2.display();

     Metric ans3 = new Metric();
     Metric.add(m, b, ans3);
     ans3.display();

     Metric ans4 = British.add(m, b);
     ans4.display();
    }
}
