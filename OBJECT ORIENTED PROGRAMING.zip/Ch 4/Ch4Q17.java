import java.util.*;
class intgcd
{private int a, b;
 public intgcd(int a, int b)
 {this.a = a; this.b = b; }
 public intgcd() {}
 public void read()
 {Scanner kbd = new Scanner(System.in);
  System.out.print("Enter two integers: ");
  a = kbd.nextInt();
  b = kbd.nextInt();
 }
 public void display()
 {System.out.println("a = "+a+"\tb = "+b);
  System.out.println("GCD = "+gcd());
  System.out.println("GCD = "+gcd1(a, b));
 }
 private int gcd()
 {int small = a<b?a:b;
  int large = a>b?a:b;
  int rem = large % small;
  while(rem!=0)
       {large = small;
        small = rem;
        rem = large % small;
       }
  return small;
 }
 private int gcd1(int x, int y)
 {if(y > x)return gcd1(y, x);
  if(y==0)return x;
  return gcd1(y, x%y);
 }
}
public class Ch4Q17 
{
  public static void main(String[] args) 
 	{intgcd x = new intgcd(30, 18);
 	 intgcd x1 = new intgcd();
 	 x1.read();
     x.display(); x1.display();
    }
}
